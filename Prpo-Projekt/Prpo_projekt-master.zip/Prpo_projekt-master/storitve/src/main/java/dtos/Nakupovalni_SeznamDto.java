package dtos;

import ent.Artikel;

import java.io.Serializable;
import java.util.List;

public class Nakupovalni_SeznamDto implements Serializable {

    private String naziv;
    private String opis;
    private int uporabnikId;
    private List<Artikel> artikli;

    //getter setter

    public String getNaziv() {
        return naziv;
    }

    public String getOpis() {
        return opis;
    }

    public int getUporabnikId(){
        return uporabnikId;
    }

    public List<Artikel> getArtikli() {
        return artikli;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public void setUporabnikId(int uporabnikId) {
        this.uporabnikId = uporabnikId;
    }

    public void setArtikli(List<Artikel> artikli) {
        this.artikli = artikli;
    }

}
