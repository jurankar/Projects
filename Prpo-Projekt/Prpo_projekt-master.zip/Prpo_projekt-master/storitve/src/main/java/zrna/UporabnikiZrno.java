package zrna;
import com.kumuluz.ee.rest.beans.QueryParameters;
import com.kumuluz.ee.rest.utils.JPAUtils;
import ent.Uporabnik;

import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.*;
import javax.persistence.*;
import javax.transaction.Transactional;

@ApplicationScoped
public class UporabnikiZrno {

    private Logger log = Logger.getLogger(UporabnikiZrno.class.getName());
    private String idZrna;

    // ko se zrno ustvari
    @PostConstruct
    private void init(){
        idZrna = UUID.randomUUID().toString();
        log.info("Inicializacija zrna "+ UporabnikiZrno.class.getSimpleName());
        // init virov
    }

    // ko se zrno unici
    @PreDestroy
    private void destros(){
        log.info("Deinicializacija zrna "+ UporabnikiZrno.class.getSimpleName());
        // zapiranje virov
    }

    @PersistenceContext(unitName = "nakupovalni-seznami-jpa")
    private EntityManager em;

    public List<Uporabnik> getUporabniki() {
        //List<Uporabnik>  uporabniki = em.createNamedQuery("uporabnik.getAll", Uporabnik.class).getResultList();
        List<Uporabnik>  uporabniki = em.createNamedQuery("Uporabnik.getAll").getResultList();
        return  uporabniki;

    }

    public List<Uporabnik> getUporabniki(QueryParameters query) {

        return JPAUtils.queryEntities(em, Uporabnik.class, query);

    }

    public Long getUporabnikiCount(QueryParameters query) {

        return JPAUtils.queryEntitiesCount(em, Uporabnik.class, query);

    }

    public List<Uporabnik> getUporabnikiByUsername(int id) {

        List<Uporabnik> uporabniki = em.createNamedQuery("Uporabnik.getUp_id").setParameter("up_id",id).getResultList();

        return uporabniki;

    }

    public Uporabnik pridobiUporabnika(int uporabnikId){

        Uporabnik uporabnik = em.find(Uporabnik.class, uporabnikId);
        return uporabnik;
    }

    @Transactional
    public Uporabnik dodajUporabnika(Uporabnik uporabnik){

        if(uporabnik != null){
            em.persist(uporabnik);
        }

        return uporabnik;
    }

    @Transactional
    public void posodobiUporabnika(int uporabnikId, Uporabnik uporabnik){

        Uporabnik u = em.find(Uporabnik.class, uporabnikId);

        uporabnik.setId(u.getId());
        em.merge(uporabnik);
    }

    @Transactional
    public Integer odstraniUporabnika(int uporabnikId){

        Uporabnik uporabnik = pridobiUporabnika(uporabnikId);

        if(uporabnik != null){
            em.remove(uporabnik);
        }

        return uporabnikId;
    }
}