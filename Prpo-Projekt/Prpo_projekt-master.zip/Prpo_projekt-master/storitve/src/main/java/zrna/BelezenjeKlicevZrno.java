package zrna;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.ApplicationScoped;
import java.util.UUID;
import java.util.logging.Logger;


@ApplicationScoped
public class BelezenjeKlicevZrno {

    private Logger log = Logger.getLogger(UporabnikiZrno.class.getName());

    private int steviloKlicev = 0;
    // ko se zrno ustvari
    @PostConstruct
    private void init(){
        log.info("Inicializacija zrna "+ BelezenjeKlicevZrno.class.getSimpleName());
        // init virov
    }

    // ko se zrno unici
    @PreDestroy
    private void destros(){
        log.info("Deinicializacija zrna "+ BelezenjeKlicevZrno.class.getSimpleName());
        // zapiranje virov
    }

    // ko se zrno kliče
    public void belezenjeKlicev(){
        steviloKlicev ++;
        log.info("Stevilo klicev: " + steviloKlicev);
    }




}
