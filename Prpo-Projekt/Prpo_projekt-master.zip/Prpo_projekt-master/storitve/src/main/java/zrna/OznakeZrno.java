package zrna;
import com.kumuluz.ee.rest.beans.QueryParameters;
import com.kumuluz.ee.rest.utils.JPAUtils;
import ent.Oznaka;
import ent.Uporabnik;

import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.*;
import javax.persistence.*;
import javax.transaction.Transactional;

@RequestScoped
public class OznakeZrno {

    private Logger log = Logger.getLogger(OznakeZrno.class.getName());
    private String idZrna;

    // ko se zrno ustvari
    @PostConstruct
    private void init(){
        idZrna = UUID.randomUUID().toString();
        log.info("Inicializacija zrna "+ OznakeZrno.class.getSimpleName());
        // init virov
    }

    // ko se zrno unici
    @PreDestroy
    private void destros(){
        log.info("Deinicializacija zrna "+ OznakeZrno.class.getSimpleName());
        // zapiranje virov
    }

    @PersistenceContext(unitName = "nakupovalni-seznami-jpa")
    private EntityManager em;

    public List<Oznaka> getOznake() {
        //List<Uporabnik>  uporabniki = em.createNamedQuery("uporabnik.getAll", Uporabnik.class).getResultList();
        List<Oznaka>  oznake = em.createNamedQuery("Oznaka.getAll").getResultList();
        return  oznake;

    }

    public List<Oznaka> getOznake(QueryParameters query) {

        return JPAUtils.queryEntities(em, Oznaka.class, query);

    }

    public Long getOznakeCount(QueryParameters query) {

        return JPAUtils.queryEntitiesCount(em, Oznaka.class, query);

    }

    public Oznaka pridobiOznako(int oznakaId){

        Oznaka oznaka = em.find(Oznaka.class, oznakaId);
        return oznaka;
    }

    @Transactional
    public Oznaka dodajOznako(Oznaka oznaka){

        if(oznaka != null){
            em.persist(oznaka);
        }

        return oznaka;
    }

    @Transactional
    public void posodobiOznako(int oznakaId, Oznaka oznaka){

        Oznaka o = em.find(Oznaka.class, oznakaId);

        oznaka.setId(o.getId());
        em.merge(oznaka);
    }

    @Transactional
    public Integer odstraniOznako(int oznakaId){

        Oznaka oznaka = pridobiOznako(oznakaId);

        if(oznaka != null){
            em.remove(oznaka);
        }

        return oznakaId;
    }
}