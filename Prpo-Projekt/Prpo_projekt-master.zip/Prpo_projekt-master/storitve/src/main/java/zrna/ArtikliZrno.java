package zrna;
import com.kumuluz.ee.rest.beans.QueryParameters;
import com.kumuluz.ee.rest.utils.JPAUtils;
import ent.Artikel;
import ent.Nakupovalni_Seznam;
import ent.Uporabnik;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.*;
import javax.inject.Inject;
import javax.persistence.*;
import javax.transaction.Transactional;
import javax.ws.rs.DELETE;
import javax.ws.rs.PUT;

@ApplicationScoped
public class ArtikliZrno {

    private Logger log = Logger.getLogger(ArtikliZrno.class.getName());
    private String idZrna;

    // ko se zrno ustvari
    @PostConstruct
    private void init(){
        idZrna = UUID.randomUUID().toString();
        log.info("Inicializacija zrna "+ ArtikliZrno.class.getSimpleName());
        // init virov
    }

    // ko se zrno unici
    @PreDestroy
    private void destros(){
        log.info("Deinicializacija zrna "+ ArtikliZrno.class.getSimpleName());
        // zapiranje virov
    }

    @PersistenceContext(unitName = "nakupovalni-seznami-jpa")
    private EntityManager em;

    @Inject
    private NakupovalniSeznamiZrno nakupovalniSeznamZrno;

    public List<Artikel> getArtikli() {
        //List<Uporabnik>  uporabniki = em.createNamedQuery("uporabnik.getAll", Uporabnik.class).getResultList();
        List<Artikel>  artikli = em.createNamedQuery("Artikel.getAll").getResultList();
        return artikli;

    }

    public List<Artikel> getArtikliNadCeno(int minCena){
        Query q = em.createNamedQuery("Artikel.getDrazjeOd");
        q.setParameter("cena", minCena);
        List <Artikel> artikli= q.getResultList();
        return artikli;
    }

    public Artikel pridobiArtikel(int artikelId){

        Artikel artikel = em.find(Artikel.class, artikelId);
        return artikel;
    }

    public List<Artikel> pridobiArtikle(QueryParameters query) {

        return JPAUtils.queryEntities(em, Artikel.class, query);

    }

    public long pridobiArtikleCount(QueryParameters query) {

        return JPAUtils.queryEntitiesCount(em, Artikel.class, query);

    }

    @Transactional
    public Artikel dodajArtikel(Artikel artikel) {

        /*if(artikel != null){
            Nakupovalni_Seznam nakupovalni_seznam = nakupovalniSeznamZrno.pridobiNakupovalniSeznam(artikel.getNakSez().getId());
            nakupovalni_seznam.dodajArtikel(artikel);
            em.persist(artikel);
        }*/

        if(artikel != null){
            em.persist(artikel);
        }

        return artikel;
    }


    @Transactional
    public void posodobiArtikel(int artikelId, Artikel artikel){

        Artikel a = em.find(Artikel.class, artikelId);

        artikel.setId(a.getId());
        em.merge(artikel);
    }

    @Transactional
    public Integer odstraniArtikel(int artikelId){

        Artikel artikel = pridobiArtikel(artikelId);

        if(artikel != null){
            em.remove(artikel);
        }

        return artikelId;
    }
}