package zrna;

import com.kumuluz.ee.rest.beans.QueryParameters;
import com.kumuluz.ee.rest.utils.JPAUtils;
import ent.Nakupovalni_Seznam;
import ent.Uporabnik;

import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.*;
import javax.inject.Inject;
import javax.persistence.*;
import javax.transaction.Transactional;

@ApplicationScoped
public class NakupovalniSeznamiZrno {

    private Logger log = Logger.getLogger(NakupovalniSeznamiZrno.class.getName());
    private String idZrna;

    // ko se zrno ustvari
    @PostConstruct
    private void init(){
        idZrna = UUID.randomUUID().toString();
        log.info("Inicializacija zrna "+ NakupovalniSeznamiZrno.class.getSimpleName());
        // init virov
    }

    // ko se zrno unici
    @PreDestroy
    private void destros(){
        log.info("Deinicializacija zrna "+ NakupovalniSeznamiZrno.class.getSimpleName());
        // zapiranje virov
    }

    @PersistenceContext(unitName = "nakupovalni-seznami-jpa")
    private EntityManager em;

    @Inject
    private UporabnikiZrno uporabnikZrno;

    public List<Nakupovalni_Seznam> pridobiNakupovalneSezname() {

        List<Nakupovalni_Seznam> seznami = em.createNamedQuery("NakupovalniSeznam.getAll").getResultList();
        return seznami;
    }

    public List<Nakupovalni_Seznam> pridobiNakupovalneSezname(QueryParameters query) {

        return JPAUtils.queryEntities(em, Nakupovalni_Seznam.class, query);

    }

    public Long pridobiNakupovalneSeznameCount(QueryParameters query) {

        return JPAUtils.queryEntitiesCount(em, Nakupovalni_Seznam.class, query);

    }

    public Nakupovalni_Seznam pridobiNakupovalniSeznam(int nakupovalni_seznam_id){

        Nakupovalni_Seznam nakupovalni_seznam = em.find(Nakupovalni_Seznam.class, nakupovalni_seznam_id);
        return nakupovalni_seznam;
    }

    @Transactional
    public Nakupovalni_Seznam dodajNakupovalniSeznam(Nakupovalni_Seznam nakupovalni_seznam) {

        if(nakupovalni_seznam != null){
            Uporabnik uporabnik = uporabnikZrno.pridobiUporabnika(nakupovalni_seznam.getUporabnik().getId());
            uporabnik.dodajNakupovalniSeznam(nakupovalni_seznam);
            em.persist(nakupovalni_seznam);
        }

        return nakupovalni_seznam;
    }

    @Transactional
    public void posodobiNakupovalniSeznam(int nakupovalni_seznam_id, Nakupovalni_Seznam nakupovalni_seznam){

        Nakupovalni_Seznam nakSeznamStari = em.find(Nakupovalni_Seznam.class, nakupovalni_seznam_id);

        nakupovalni_seznam.setId(nakSeznamStari.getId());
        em.merge(nakupovalni_seznam);
    }

    @Transactional
    public Integer odstraniNakupovalniSeznam(int nakupovalni_seznam_id){

        Nakupovalni_Seznam nakupovalni_seznam = pridobiNakupovalniSeznam(nakupovalni_seznam_id);

        if(nakupovalni_seznam != null){
            em.remove(nakupovalni_seznam);
        }

        return nakupovalni_seznam_id;
    }
}
