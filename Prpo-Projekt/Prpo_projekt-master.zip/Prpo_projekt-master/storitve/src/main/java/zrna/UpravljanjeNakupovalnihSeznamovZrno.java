package zrna;


import dtos.Nakupovalni_SeznamDto;
import ent.*;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.json.JsonObject;
import javax.json.stream.JsonParser;
import javax.transaction.Transactional;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

@ApplicationScoped
public class UpravljanjeNakupovalnihSeznamovZrno {

    private Logger log = Logger.getLogger(UpravljanjeNakupovalnihSeznamovZrno.class.getName());

    @Inject
    private UporabnikiZrno uporabnikiZrno;

    @Inject
    private  NakupovalniSeznamiZrno nakupovalniSeznamiZrno;

    @Inject
    private  OznakeZrno oznakeZrno;

    @Inject
    private ArtikliZrno artikelZrno;



    // ko se zrno ustvari
    @PostConstruct
    private void init(){
        log.info("Inicializacija zrna "+ UpravljanjeNakupovalnihSeznamovZrno.class.getSimpleName());
        // init virov
    }

    // ko se zrno unici
    @PreDestroy
    private void destros(){
        log.info("Deinicializacija zrna "+ UpravljanjeNakupovalnihSeznamovZrno.class.getSimpleName());
        // zapiranje virov
    }

    public Nakupovalni_Seznam ustvariNakupovalniSeznam(Nakupovalni_SeznamDto nakupovalniSeznamDto) throws Exception {

        Uporabnik uporabnik = uporabnikiZrno.pridobiUporabnika(nakupovalniSeznamDto.getUporabnikId());

        if(uporabnik == null){
            log.info("Ne morem ustvariti novega nakupovalnega seznama. Uporabnik ne obstaja.");
            return null;
        }

        Nakupovalni_Seznam nakupovalni_seznam = new Nakupovalni_Seznam();
        nakupovalni_seznam.setUporabnik(uporabnik);
        nakupovalni_seznam.setNaziv(nakupovalniSeznamDto.getNaziv());
        nakupovalni_seznam.setOpis(nakupovalniSeznamDto.getOpis());
        nakupovalni_seznam.setUstvarjen(Instant.now());
        nakupovalni_seznam.setImageLink(pridobiSliko(nakupovalni_seznam.getNaziv()));

        return  nakupovalniSeznamiZrno.dodajNakupovalniSeznam(nakupovalni_seznam);
    }

    @Transactional
    public int odstraniSeznam(int id) {
        Nakupovalni_Seznam nakupovalni_seznam = nakupovalniSeznamiZrno.pridobiNakupovalniSeznam(id);

        if (nakupovalni_seznam == null) {
            return -1;
        }

        Uporabnik uporabnik = uporabnikiZrno.pridobiUporabnika(nakupovalni_seznam.getUporabnik().getId());

        if (uporabnik == null) {
            return -1;
        }

        nakupovalniSeznamiZrno.odstraniNakupovalniSeznam(nakupovalni_seznam.getId());
        uporabnik.getNakupovalniSeznami().remove(nakupovalni_seznam);

        return id;
    }

    public int skupnaCenaNarocila(Nakupovalni_SeznamDto nakupovalniSeznamDto){

        int skupnaCena = 0;
        List<Artikel> artikli = nakupovalniSeznamDto.getArtikli();
        int stArtiklov = artikli.size();

        for(int i = 0; i < stArtiklov; i++){
            Artikel art = artikli.get(i);
            int cena = art.getCena();
            int kolicina = art.getKolicina();
            skupnaCena += cena * kolicina;
        }

        return skupnaCena;
    }

    public List<Artikel> artikliDrazjiOd(int minCena, int uporabnikID){
        //gre cez vse sezname in najde drage artikle
        //smiselno za hitro estimacijo cene
        // --> ce kupimo kosilnico 200EUR + laptop 500EUR + kečap 1EUR + salamo 3EUR + pašteto 0.5EUR + spageti 1EUR
        // --> potem nam kosilnica in laptop pokrijeta 98% cene

        Uporabnik up = uporabnikiZrno.pridobiUporabnika(uporabnikID);
        List<Artikel> dragiArtikli = new ArrayList();
        List<Nakupovalni_Seznam> nakSeznami = up.getNakupovalniSeznami();
        int stSeznamov = nakSeznami.size();

        //cez vse sezname
        for(int i = 0; i < stSeznamov; i++){

            //cez vse artikle na seznamu
            Nakupovalni_Seznam nak = nakSeznami.get(i);
            List<Artikel> artikliSeznama = nak.getSeznamArtiklov();
            int velikostSeznama = artikliSeznama.size();
            for(int j = 0; j < velikostSeznama; j++){
                Artikel art = artikliSeznama.get(j);
                if(art.getCena() >= minCena){
                    dragiArtikli.add(art);
                }
            }
        }

        Nakupovalni_Seznam nak = new Nakupovalni_Seznam();
        nak.setNaziv("Dragi_Artikli");
        nak.setOpis("Artikli drazji od " + minCena + " EUR.");
        nak.setSeznamArtiklov(dragiArtikli);
        nak.setUporabnik(up);

        // ustvari oznako za seznam in jo dodaj v bazo
        Oznaka dragaOznaka = new Oznaka();
        dragaOznaka.setNaslov("drago");
        dragaOznaka.setOpis("Na tem seznamu so vsi artikli, ki so drazji od " + minCena + " EUR.");
        oznakeZrno.dodajOznako(dragaOznaka);
        // dodaj oznako na seznam
        List<Oznaka> vseOznakeSeznama = nak.getOznake();
        vseOznakeSeznama.add(dragaOznaka);

        nakupovalniSeznamiZrno.dodajNakupovalniSeznam(nak);
        return dragiArtikli;
    }

    public void odstraniNeveljavneArtikle(Nakupovalni_Seznam nak) {

        List<Artikel> vsiArtikliSeznama = nak.getSeznamArtiklov();

        for (int i = 0; i < vsiArtikliSeznama.size(); i++) {
            // ce je cena artikla 0 ali manj, ga odstrani
            Artikel trenutniArtikel = vsiArtikliSeznama.get(i);
            if(trenutniArtikel.getCena() <= 0){
                vsiArtikliSeznama.remove(trenutniArtikel);
                artikelZrno.odstraniArtikel(trenutniArtikel.getId());
            }
        }
        nakupovalniSeznamiZrno.posodobiNakupovalniSeznam(nak.getId(), nak);

    }

    public Nakupovalni_Seznam pridobiNakupovalniSeznam(int id){
        Nakupovalni_Seznam nakupovalni_seznam = nakupovalniSeznamiZrno.pridobiNakupovalniSeznam(id);

        if(nakupovalni_seznam == null) {
            System.out.println("Napaka");
            return null;
        }

        return nakupovalni_seznam;
    }

    // s pmočjo zunanjega API klica pridobi sliko za nakupovalni seznam
    public static String pridobiSliko(String beseda) throws Exception{
        String url = "https://app.zenserp.com/api/v2/search?q="+beseda+"&tbm=isch&hl=en&gl=US&location=United%20States&search_engine=google.com&apikey=b5228330-264a-11ea-8b36-55d48aca2978";
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        // optional default is GET
        con.setRequestMethod("GET");
        //add request header
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        int responseCode = con.getResponseCode();
        System.out.println("\nSending 'GET' request to URL : " + url);
        System.out.println("Response Code : " + responseCode);
        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();
        //print in String
        //System.out.println(response.toString());

        // Create json from string buffer
        String responseStr = response.toString();
        JSONObject responseObject = new JSONObject(responseStr);
        JSONArray linkArray = responseObject.getJSONArray("image_results");
        JSONObject  linkObject= linkArray.getJSONObject(0);
        String link = linkObject.getString("sourceUrl");
        System.out.println(link);
        //return  response.toString();
        return  link;
    }
}
