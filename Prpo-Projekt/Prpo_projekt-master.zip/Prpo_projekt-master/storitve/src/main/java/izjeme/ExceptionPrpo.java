package izjeme;

public class ExceptionPrpo extends RuntimeException {
    public ExceptionPrpo(String err){
        super(err);
    }
}
