package interceptorji;

import anotacije.BeleziKlice;
import zrna.BelezenjeKlicevZrno;

import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

@Interceptor
@BeleziKlice
public class BelezenjeKlicevInterceptor {

    //Logger log = Logger.getLogger(SteviloIzvajanjMetodeDtoInterceptor.class)
    @Inject
    private BelezenjeKlicevZrno belezenjeKlicevZrno;

    @AroundInvoke
    public Object steviloIzvajanjMetode(InvocationContext invocationContext) throws Exception{

        belezenjeKlicevZrno.belezenjeKlicev();

        return invocationContext.proceed();
    }


}

/*
        if(context.getParameters().length == 1 && context.getParameters()[0] instanceof  Integer){
            int stIzvajanjFunkcije  = (Integer) context.getParameters()[0];
            stIzvajanjFunkcije += 1;

            context.setParameters(new Object[]{stIzvajanjFunkcije});

        }

 */