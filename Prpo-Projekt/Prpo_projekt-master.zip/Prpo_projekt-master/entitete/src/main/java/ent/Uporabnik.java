package ent;


import javax.persistence.*;
import java.util.List;

@Entity(name = "uporabnik")
@NamedQueries(value =
        {
                @NamedQuery(name = "Uporabnik.getAll", query = "SELECT u FROM uporabnik u"),
                @NamedQuery(name = "Uporabnik.getJanez", query = "SELECT up FROM uporabnik up WHERE up.ime = 'Janez'"),
                @NamedQuery(name = "Uporabnik.getUp_ime", query = "SELECT up FROM uporabnik up WHERE up.ime = :up_ime"),
                @NamedQuery(name = "Uporabnik.getUp_id", query = "SELECT up FROM uporabnik up WHERE up.id = :up_id")
        })
public class Uporabnik {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "ime")
    private String ime;

    @Column(name = "priimek")
    private String priimek;

    @Column(name = "uporabnisko_ime")
    private String uporabniskoIme;

    @Column(name = "email")
    private String email;

    @OneToMany(mappedBy = "uporabnik", cascade = CascadeType.ALL)
    private List<Nakupovalni_Seznam> nakupovalniSeznami;

    public void dodajNakupovalniSeznam(Nakupovalni_Seznam nakupovalni_seznam){
        nakupovalniSeznami.add(nakupovalni_seznam);
    }


    // Getterji in Setterji
    public Integer getId(){
        return id;
    }

    public void setId(Integer id){
        this.id=id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPriimek() {
        return priimek;
    }

    public void setPriimek(String priimek) {
        this.priimek = priimek;
    }

    public String getUporabniskoIme() {
        return uporabniskoIme;
    }

    public void setUporabniskoIme(String uporabniskoIme) {
        this.uporabniskoIme = uporabniskoIme;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<Nakupovalni_Seznam> getNakupovalniSeznami() {
        return nakupovalniSeznami;
    }

    public void setNakupovalniSeznami(List<Nakupovalni_Seznam> nakupovalniSeznami) {
        this.nakupovalniSeznami = nakupovalniSeznami;
    }
}