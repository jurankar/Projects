package ent;

public class ArtikelMikro {

    private String imeArtikla;

    //getter

    public String getImeArtikla() {
        return imeArtikla;
    }

    //setter

    public void setImeArtikla(String imeArtikla) {
        this.imeArtikla = imeArtikla;
    }
}
