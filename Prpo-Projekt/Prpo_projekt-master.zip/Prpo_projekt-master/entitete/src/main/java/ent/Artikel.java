package ent;


import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.*;

@Entity(name = "Artikel")
@NamedQueries(value =
        {
                @NamedQuery(name = "Artikel.getAll", query = "SELECT a FROM Artikel a"),
                @NamedQuery(name = "Artikel.getDrazjeOd", query = "SELECT a.imeArtikla FROM Artikel a WHERE  a.cena > :cena")
        })
public class Artikel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "ime")
    private String imeArtikla;

    @Column(name = "cena")
    private Integer cena;

    @Column(name = "kolicina")
    private Integer kolicina;

    @JsonbTransient
    @ManyToOne
    @JoinColumn(name = "nakupovalniSeznam")  //--> polje je random ime
    private Nakupovalni_Seznam nakSez;

    // getter in setter metode


    public Integer getId() {
        return id;
    }

    public String getImeArtikla() {
        return imeArtikla;
    }

    public Integer getCena() {
        return cena;
    }

    public Integer getKolicina() {
        return kolicina;
    }

    public Nakupovalni_Seznam getNakSez() {
        return nakSez;
    }


    public void setId(Integer id) {
        this.id = id;
    }

    public void setImeArtikla(String imeArtikla) {
        this.imeArtikla = imeArtikla;
    }

    public void setCena(Integer cena) {
        this.cena = cena;
    }

    public void setKolicina(Integer kolicina) {
        this.kolicina = kolicina;
    }

    public void setNakSez(Nakupovalni_Seznam nakSez) {
        this.nakSez = nakSez;
    }
}