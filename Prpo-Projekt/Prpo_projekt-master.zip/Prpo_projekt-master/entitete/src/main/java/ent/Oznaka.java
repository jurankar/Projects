package ent;
import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.*;
import java.util.List;


@Entity(name = "oznaka")
@NamedQueries(value =
        {
                @NamedQuery(name = "Oznaka.getAll", query = "SELECT o FROM oznaka o")
        })
public class Oznaka {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String naslov;

    private String opis;


    @JsonbTransient
    @ManyToMany(mappedBy = "oznake")    // --> ime entitete
    private List<Nakupovalni_Seznam> nakupovalniSeznami;

    // getter in setter metode

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNaslov() {
        return naslov;
    }

    public void setNaslov(String naslov) {
        this.naslov = naslov;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }
}