package ent;


import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.*;
import java.time.Instant;
import java.util.List;

@Entity
@Table(name = "Nakupovalni_seznam")
@NamedQueries(value =
        {
                @NamedQuery(name = "NakupovalniSeznam.getAll",
                        query = "SELECT ns FROM Nakupovalni_Seznam ns"),
                @NamedQuery(name = "Opomnik.getMajhneSezname",
                        query = "SELECT ns FROM Nakupovalni_Seznam ns WHERE size(ns.seznamArtiklov) <= 4")
        })

public class Nakupovalni_Seznam {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "naziv")
    private String naziv;

    @Column(name = "opis")
    private String opis;

    @Column(name = "ustvarjen")
    private Instant ustvarjen;

    @JsonbTransient
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "uporabnik_id")
    private Uporabnik uporabnik;


    @OneToMany(mappedBy = "nakSez")     // --> ime spremenljivke
    private List<Artikel> seznamArtiklov;

    @ManyToMany(cascade = {
          CascadeType.PERSIST,
          CascadeType.MERGE
    })
    @JoinTable(name = "nakupovalni_seznam_oznaka",
        joinColumns = @JoinColumn(name = "nakupovalni_seznam_id"),
        inverseJoinColumns = @JoinColumn(name = "oznaka_id")
    )
    private  List<Oznaka> oznake;

    @Column(name = "imageLink")
    private String imageLink;

    public void dodajArtikel(Artikel artikel) {
        seznamArtiklov.add(artikel);
    }

    // getter in setter metode

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public Instant getUstvarjen() {
        return ustvarjen;
    }

    public void setUstvarjen(Instant ustvarjen) {
        this.ustvarjen = ustvarjen;
    }

    public Uporabnik getUporabnik() {
        return uporabnik;
    }

    public void setUporabnik(Uporabnik uporabnik) {
        this.uporabnik = uporabnik;
    }

    public List<Artikel> getSeznamArtiklov() {
        return seznamArtiklov;
    }

    public void setSeznamArtiklov(List<Artikel> seznamArtiklov) {
        this.seznamArtiklov = seznamArtiklov;
    }

    public List<Oznaka> getOznake() {
        return oznake;
    }

    public void setOznake(List<Oznaka> oznake) {
        this.oznake = oznake;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }


}