package si.fri.prpo.sovaura.api.v1.viri;

import anotacije.BeleziKlice;
import com.kumuluz.ee.cors.annotations.CrossOrigin;
import com.kumuluz.ee.rest.beans.QueryParameters;
import ent.Uporabnik;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import zrna.UporabnikiZrno;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.util.logging.Logger;
import java.util.List;

@Path("uporabniki")
@CrossOrigin(supportedMethods = "GET,POST,HEAD,OPTIONS,PUT,DELETE")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@ApplicationScoped

@BeleziKlice

public class UporabnikiVir {

    //private Logger log = Logger.getLogger(UporabnikiVir.class.getName());

    @Inject
    private UporabnikiZrno uporabnikiZrno;

    @Context
    protected UriInfo uriInfo;

    @Operation(description = "Vrne seznam uporabnikov.", summary = "Vrne seznam uporabnikov.",
            tags = "Uporabniki", responses = {
            @ApiResponse(responseCode = "200",
                    description = "Seznam uporabnikov",
                    content = @Content(
                            array = @ArraySchema(
                                    schema = @Schema(implementation = Uporabnik.class)
                            )),
                    headers = {@Header(name = "X-Total-Count", description = "Stevilo vrnjenih uporabnikov.")}
            )})
    @SecurityRequirement(name = "openid-connect")
    @GET
    public Response pridobiUporabnike(){

        //List<Uporabnik> uporabniki = uporabnikiZrno.getUporabniki();
        //return Response.ok(uporabnikiZrno.getUporabniki()).build();

        QueryParameters query = QueryParameters.query(uriInfo.getRequestUri().getQuery()).build();
        List<Uporabnik> uporabniki = uporabnikiZrno.getUporabniki(query);
        Long uporabnikiCount = uporabnikiZrno.getUporabnikiCount(query);
        return Response.status(Response.Status.OK).header("X-Total-Count", uporabnikiCount).entity(uporabniki).build();
    }

    @Operation(description = "Vrne uporabnika s podanim ID-jem.", summary = "Vrne uporabnika s podanim ID-jem.",
            tags = "Uporabniki", responses = {
            @ApiResponse(responseCode = "200",
                    description = "Uporabnika",
                    content = @Content(
                            schema = @Schema(implementation = Uporabnik.class))
            )})
    @GET
    @Path("{id}")
    public Response pridobiUporabnika(@PathParam("id") Integer id){

        Uporabnik uporabnik = uporabnikiZrno.pridobiUporabnika(id);

        if(uporabnik != null){
            return Response.ok(uporabnik).build();
        }
        else{
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }

    @Operation(description = "Dodaj uporabnika.", summary = "Dodaj uporabnika.",
            tags = "Uporabniki", responses = {
            @ApiResponse(responseCode = "201",
                    description = "Uporabnik dodan."
            ),
            @ApiResponse(responseCode = "405", description = "Napaka.")
    })
    @POST
    public Response dodajUporabnika(Uporabnik uporabnik) {

        return Response
                .status(Response.Status.CREATED)
                .entity(uporabnikiZrno.dodajUporabnika(uporabnik))
                .build();
    }

    @Operation(description = "Posodobi uporabnika.", summary = "Posodobi uporabnika.",
            tags = "Uporabniki", responses = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Uporabnik posodobljen."
            )
    })
    @PUT
    @Path("{id}")
    public Response posodobiUporabnika(@PathParam("id") Integer id, Uporabnik uporabnik){

        uporabnikiZrno.posodobiUporabnika(id, uporabnik);

        return Response.status(Response.Status.OK)
                .entity(uporabnikiZrno.pridobiUporabnika(id))
                .build();
    }

    @Operation(description = "Odstrani uporabnika.", summary = "Odstrani uporabnika.",
            tags = "Uporabniki",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Uporabnik odstranjen."
                    ), @ApiResponse(
                    responseCode = "404",
                    description = "Uporabnik ne obstaja."
            )
            })
    @DELETE
    @Path("{id}")
    public Response odstraniUporabnika(@PathParam("id") Integer id){

        return Response
                .status(Response.Status.NO_CONTENT)
                .entity(uporabnikiZrno.odstraniUporabnika(id))
                .build();

    }

}

