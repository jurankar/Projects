package si.fri.prpo.sovaura.api.v1.viri;


import com.kumuluz.ee.cors.annotations.CrossOrigin;
import com.kumuluz.ee.rest.beans.QueryParameters;
import ent.Oznaka;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import zrna.OznakeZrno;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.util.List;

@ApplicationScoped
@Path("oznake")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@CrossOrigin(supportedMethods = "GET,POST,HEAD,OPTIONS,PUT,DELETE")

public class OznakeVir {

    @Inject
    private OznakeZrno oznakeZrno;

    @Context
    protected UriInfo uriInfo;

    @Operation(description = "Vrne seznam oznak.", summary = "Vrne seznam oznak.",
            tags = "Oznake", responses = {
            @ApiResponse(responseCode = "200",
                    description = "Seznam oznak",
                    content = @Content(
                            array = @ArraySchema(
                                    schema = @Schema(implementation = Oznaka.class)
                            )),
                    headers = {@Header(name = "X-Total-Count", description = "Stevilo vrnjenih oznak.")}
            )})
    @GET
    public Response pridobiOznake(){

        //List<Oznaka> oznake = oznakeZrno.getOznake();
        //return Response.status(Response.Status.OK).entity(oznake).build();

        QueryParameters query = QueryParameters.query(uriInfo.getRequestUri().getQuery()).build();
        Long oznakeCount = oznakeZrno.getOznakeCount(query);

        return Response.ok(oznakeZrno.getOznake(query)).header("X-Total-Count", oznakeCount).build();
    }

    @Operation(description = "Vrne oznako s podanim ID.jem.", summary = "Vrne oznako s podanim ID.jem.",
            tags = "Oznake", responses = {
            @ApiResponse(responseCode = "200",
                    description = "Oznaka z ID-jem",
                    content = @Content(
                            schema = @Schema(implementation = Oznaka.class))
            )})
    @GET
    @Path("{id}")
    public Response pridobiOznako(@PathParam("id") Integer id){

        Oznaka oznaka = oznakeZrno.pridobiOznako(id);

        if(oznaka != null){
            return Response.ok(oznaka).build();
        }
        else{
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }

    @Operation(description = "Dodaj oznako.", summary = "Dodaj oznako.",
            tags = "Oznake", responses = {
            @ApiResponse(responseCode = "201",
                    description = "Oznaka dodana."
            ),
            @ApiResponse(responseCode = "405", description = "Napaka.")
    })
    @POST
    public Response dodajOznako(Oznaka oznaka) {

        return Response
                .status(Response.Status.CREATED)
                .entity(oznakeZrno.dodajOznako(oznaka))
                .build();
    }

    @Operation(description = "Posodobi oznako.", summary = "Posodabi oznako.",
            tags = "Oznake", responses = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Oznaka uspesno posodobljena."
            )
    })
    @PUT
    @Path("{id}")
    public Response posodobiOznako(@PathParam("id") Integer id, Oznaka oznaka){

        oznakeZrno.posodobiOznako(id, oznaka);

        return Response.status(Response.Status.OK)
                .entity(oznakeZrno.pridobiOznako(id))
                .build();

    }


    @Operation(description = "Odstrani oznako.", summary = "Odstrani oznako.",
            tags = "Oznake",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Oznaka uspesno odstranjena."
                    ), @ApiResponse(
                    responseCode = "404",
                    description = "Oznaka ne obstaja."
            )
            })
    @DELETE
    @Path("{id}")
    public Response odstraniOznako(@PathParam("id") Integer id){

        return Response.status(Response.Status.NO_CONTENT)
                .entity(oznakeZrno.odstraniOznako(id))
                .build();

    }

}
