package si.fri.prpo.sovaura.api.v1.viri;


import com.kumuluz.ee.cors.annotations.CrossOrigin;
import com.kumuluz.ee.rest.beans.QueryParameters;
import ent.Artikel;
import ent.ArtikelMikro;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import zrna.ArtikliZrno;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

@ApplicationScoped
@Path("artikli")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@CrossOrigin(supportedMethods = "GET,POST,HEAD,OPTIONS,PUT,DELETE")

public class ArtikliVir {

    private Client httpClient;
    private String baseUrl;

    @PostConstruct
    private void init() {
        httpClient = ClientBuilder.newClient();
        baseUrl = "http://localhost:8081/v1";
    }


    @Inject
    private ArtikliZrno artikliZrno;

    @Context
    protected UriInfo uriInfo;

    @Operation(description = "Vrne seznam artiklov nakupovalnega seznama.", summary = "Vrne seznam artiklov nakupovalnega seznama.",
            tags = "Artikli", responses = {
            @ApiResponse(responseCode = "200",
                    description = "Seznam artiklov",
                    content = @Content(
                            array = @ArraySchema(
                                    schema = @Schema(implementation = Artikel.class)
                            ))
            )
    }
    )
    @GET
    public Response pridobiArtikle(){
        //List<Artikel> artikli = artikliZrno.getArtikli();

        QueryParameters query = QueryParameters.query(uriInfo.getRequestUri().getQuery()).build();
        long nakupovalniSeznamiCount = artikliZrno.pridobiArtikleCount(query);

        //return Response.status(Response.Status.OK).entity(artikli).build();
        return Response.ok(artikliZrno.pridobiArtikle(query)).header("X-Total-Count", nakupovalniSeznamiCount).build();
    }

    @Operation(description = "Vrne artikel s podanim ID.", summary = "Vrne artikel s podanim ID.",
            tags = "Artikli", responses = {
            @ApiResponse(responseCode = "200",
                    description = "Artikel",
                    content = @Content(
                            array = @ArraySchema(
                                    schema = @Schema(implementation = Artikel.class)
                            ))
            )
    }
    )
    @GET
    @Path("{id}")
    public Response pridobiArtikel(@PathParam("id") Integer id){

        Artikel artikel = artikliZrno.pridobiArtikel(id);

        if(artikel != null){
            return Response.ok(artikel).build();
        }
        else{
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }

    @Operation(description = "Doda artikel v bazo.", summary = "Doda artikel v bazo.",
            tags = "Artikli", responses = {
            @ApiResponse(responseCode = "201",
                    description = "Artikel dodan."
            ),
            @ApiResponse(responseCode = "405", description = "Napaka.")
    })
    @POST
    public Response dodajArtikel(Artikel artikel) {


        //naredi nov objekt ArtikelMikro iz Artikel
        ArtikelMikro artikel_mikro = new ArtikelMikro();
        artikel_mikro.setImeArtikla( artikel.getImeArtikla() );

        // pošlji 2. mikrostoritvi
        httpClient.target(baseUrl + "/pogosti_artikli")
                .request().post(Entity.entity(artikel_mikro,MediaType.APPLICATION_JSON));

        return Response
                .status(Response.Status.CREATED)
                .entity(artikliZrno.dodajArtikel(artikel))
                .build();
    }

    @Operation(description = "Posodobi artikel.", summary = "Posodobi artikla.",
            tags = "Artikli",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Artikel posodobljen."
                    )
            })
    @PUT
    @Path("{id}")
    public Response posodobiArtikel(@PathParam("id") Integer id, Artikel artikel){

        artikliZrno.posodobiArtikel(id,artikel);

        return Response
                .status(Response.Status.CREATED)
                .entity(artikliZrno.pridobiArtikel(id))
                .build();
    }


    @Operation(description = "Odstrani artikel.", summary = "Odstrani artikla.",
            tags = "Artikli",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Artikel odstranjen."
                    ), @ApiResponse(
                    responseCode = "404",
                    description = "Artikel ne obstaja."
            )
            }
    )
    @DELETE
    @Path("{id}")
    public Response odstraniArtikel(@PathParam("id") Integer id){

        return Response
                .status(Response.Status.NO_CONTENT)
                .entity(artikliZrno.odstraniArtikel(id))
                .build();

    }

}
