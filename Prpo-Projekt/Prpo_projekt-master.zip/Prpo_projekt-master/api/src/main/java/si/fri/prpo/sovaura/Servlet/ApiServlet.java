package si.fri.prpo.sovaura.Servlet;

import ent.Uporabnik;
import si.fri.prpo.sovaura.api.v1.viri.MikrostoritevServer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.List;

@WebServlet("/apiServlet")
public class ApiServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        MikrostoritevServer mikro = new MikrostoritevServer();
        mikro.getPogostiArtikel();

        /*
        for (int i = 0; i < uporabniki.size(); i++) {
            System.out.printf("%s %s %s %s\n",uporabniki.get(i).getId(),uporabniki.get(i).getIme(),uporabniki.get(i).getPriimek(),uporabniki.get(i).getEmail());
            resp.getWriter().printf("%s %s %s %s\n",uporabniki.get(i).getId(),uporabniki.get(i).getIme(),uporabniki.get(i).getPriimek(),uporabniki.get(i).getEmail());
        }
        */


        //uporabnikiZrno.getUporabniki().stream().forEach(u -> writer.append(u.toString() + "<br/><br/>"));


    }

}