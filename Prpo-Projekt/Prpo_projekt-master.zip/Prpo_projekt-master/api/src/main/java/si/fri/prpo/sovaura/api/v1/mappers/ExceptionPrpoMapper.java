package si.fri.prpo.sovaura.api.v1.mappers;



import izjeme.ExceptionPrpo;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class ExceptionPrpoMapper implements ExceptionMapper<ExceptionPrpo> {

    @Override
    public Response toResponse(ExceptionPrpo ex){
        return Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();

    }
}
