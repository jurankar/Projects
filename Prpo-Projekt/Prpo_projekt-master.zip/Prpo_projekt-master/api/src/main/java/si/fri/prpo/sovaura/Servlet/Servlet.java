package si.fri.prpo.sovaura.Servlet;

import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import ent.Uporabnik;
import zrna.UporabnikiZrno;

@WebServlet("/servlet")
public class Servlet extends HttpServlet {

    @Inject
    private UporabnikiZrno uporabnikiZrno;

    private static final Logger log = Logger.getLogger(Servlet.class.getName());

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        //resp.setContentType("/text/html; charset=UTF-8");
        //resp.setCharacterEncoding("UTF-8");

        //PrintWriter writer = resp.getWriter();

        //writer.append("<br/><br/>Uporabniki:<br/>");

        List<Uporabnik> uporabniki = uporabnikiZrno.getUporabniki();
        for (int i = 0; i < uporabniki.size(); i++) {
            System.out.printf("%s %s %s %s\n",uporabniki.get(i).getId(),uporabniki.get(i).getIme(),uporabniki.get(i).getPriimek(),uporabniki.get(i).getEmail());
            resp.getWriter().printf("%s %s %s %s\n",uporabniki.get(i).getId(),uporabniki.get(i).getIme(),uporabniki.get(i).getPriimek(),uporabniki.get(i).getEmail());
        }



        //uporabnikiZrno.getUporabniki().stream().forEach(u -> writer.append(u.toString() + "<br/><br/>"));


    }
}

// docker start 8fcfce82df4f927bdcc4657537606edd01fa0838a85c6a3753159a85c328c053 --> jan docker container