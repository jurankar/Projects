package si.fri.prpo.sovaura.api.v1.viri;

import javax.annotation.PostConstruct;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;


public class MikrostoritevServer {

    String baseUrl = "http://localhost:8081/v1";
    private Client httpClient;

    @PostConstruct
    private void init() {
        httpClient = ClientBuilder.newClient();

        /*
        requestAllOrders(client);

        requestOrderById(client, "343");
        requestAllItemsByOrderId(client, "343");
        requestItemByOrderIdAndItemId(client, "343", "343");
        */
    }

    public void getPogostiArtikel() {
        WebTarget target = httpClient.target("http://localhost:8081/v1/priporocila");
/*        Response res = httpClient
                .target("http://localhost:8081/v1/priporocila/3")
                .request().get();
*/        //using response object to get more information
       // Response s = target.request().get();
        //System.out.println("response: " + s.getEntity() + ",  status " + s.getStatus());
        //return s;

    }

    /*
    private static void requestAllItemsByOrderId(Client client, String orderId) {
        WebTarget target = client.target("http://localhost:8080/jaxrs-client-api-example/api/orders/" +
                orderId + "/items");
        String s = target.request().get(String.class);
        System.out.println("response : " + s);
    }

    private static void requestOrderById(Client client, String orderId) {
        WebTarget target = client.target("http://localhost:8080/jaxrs-client-api-example/api/orders/" +
                orderId);
        String s = target.request().get(String.class);
        System.out.println("response : " + s);

    }

    private static void requestAllOrders(Client client) {
        WebTarget target = client.target("http://localhost:8080/jaxrs-client-api-example/api/orders");
        String s = target.request().get(String.class);
        System.out.println("response : " + s);
    }

     */
}
