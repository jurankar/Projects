package si.fri.prpo.sovaura.api.v1.viri;


import anotacije.BeleziKlice;
import com.kumuluz.ee.cors.annotations.CrossOrigin;
import com.kumuluz.ee.rest.beans.QueryParameters;
import dtos.Nakupovalni_SeznamDto;
import ent.Nakupovalni_Seznam;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import zrna.NakupovalniSeznamiZrno;
import zrna.UpravljanjeNakupovalnihSeznamovZrno;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import java.util.List;
import java.util.logging.Logger;

@ApplicationScoped
@Path("nakupovalni_seznami")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@BeleziKlice
@CrossOrigin(supportedMethods = "GET,POST,HEAD,OPTIONS,PUT,DELETE")

public class NakupovalniSeznamiVir {

    //private Logger log = Logger.getLogger(UporabnikiVir.class.getName());

    @Inject
    private NakupovalniSeznamiZrno nakupovalniSeznamiZrno;

    @Inject
    private UpravljanjeNakupovalnihSeznamovZrno upravljanjeNakupovalnihSeznamovZrno;

    @Context
    protected UriInfo uriInfo;

    @Operation(description = "Vrne seznam nakupovalnih seznamov.", summary = "Vrne seznam nakupovalnih seznamov.",
            tags = "Nakupovalni seznami", responses = {
            @ApiResponse(responseCode = "200",
                    description = "Nakupovalni seznami",
                    content = @Content(
                            array = @ArraySchema(
                                    schema = @Schema(implementation = Nakupovalni_Seznam.class)
                            ))
            )
    }
    )
    @GET
    public Response pridobiNakupovalneSezname(){

        //List<Nakupovalni_Seznam> seznami = nakupovalniSeznamiZrno.pridobiNakupovalneSezname();

        //return Response.status(Response.Status.OK).entity(nakupovalniSeznamiZrno.pridobiNakupovalneSezname()).build();

        QueryParameters query = QueryParameters.query(uriInfo.getRequestUri().getQuery()).build();
        Long nakupovalniSeznamiCount = nakupovalniSeznamiZrno.pridobiNakupovalneSeznameCount(query);

        return Response.ok(nakupovalniSeznamiZrno.pridobiNakupovalneSezname(query)).header("X-Total-Count", nakupovalniSeznamiCount).build();
    }

    @Operation(description = "Vrne nakupovalni seznam s podanim ID-jem.", summary = "Vrne nakupovalni seznam s podanim ID-jem.",
            tags = "Nakupovalni seznami", responses = {
            @ApiResponse(responseCode = "200",
                    description = "Nakupovalni seznam s podanim ID-jem",
                    content = @Content(
                            array = @ArraySchema(
                                    schema = @Schema(implementation = Nakupovalni_Seznam.class)
                            ))
            )
    }
    )
    @GET
    @Path("{id}")
    public Response pridobiNakupovalniSeznam(@PathParam("id") Integer id){

        Nakupovalni_Seznam nakupovalni_seznam = nakupovalniSeznamiZrno.pridobiNakupovalniSeznam(id);

        if(nakupovalni_seznam != null){
            return Response.ok(nakupovalni_seznam).entity(nakupovalni_seznam).build();
        }
        else{
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }

    @Operation(description = "Dodaj nakupovalni seznam.", summary = "Dodaj nakupovalni seznam.",
            tags = "Nakupovalni seznami", responses = {
            @ApiResponse(responseCode = "201",
                    description = "Seznam dodan."
            ),
            @ApiResponse(responseCode = "405", description = "Napaka.")
    })
    @POST
    public Response dodajNakupovalniSeznam(Nakupovalni_SeznamDto nakupovalni_seznamDto) throws Exception {

        Nakupovalni_Seznam nakupovalniSeznam = upravljanjeNakupovalnihSeznamovZrno.ustvariNakupovalniSeznam(nakupovalni_seznamDto);

        if (nakupovalniSeznam != null){
            return Response.status(Response.Status.CREATED).entity(nakupovalniSeznam).build();
        }
        else {
            return Response.status(Response.Status.NOT_MODIFIED).build();
        }
    }

    @Operation(description = "Posodobi nakupovalni seznam.", summary = "Posodobi nakupovalni seznam.",
            tags = "Nakupovalni seznami",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Seznam posodobljen."
                    )
            }
    )
    @PUT
    @Path("{id}")
    public Response posodobiNakupovalniSeznam(@PathParam("id") Integer id, Nakupovalni_Seznam nakupovalni_seznam){

        nakupovalni_seznam.setUporabnik(nakupovalniSeznamiZrno.pridobiNakupovalniSeznam(id).getUporabnik());
        nakupovalniSeznamiZrno.posodobiNakupovalniSeznam(id, nakupovalni_seznam);

        return Response
                .status(Response.Status.OK)
                .entity(nakupovalniSeznamiZrno.pridobiNakupovalniSeznam(id))
                .build();
    }


    @Operation(description = "Odstrani nakupovalni seznam.", summary = "Odstrani nakupovalni seznam.",
            tags = "Nakupovalni seznami",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Seznam odstranjen."
                    ), @ApiResponse(
                    responseCode = "404",
                    description = "Seznam ne obstaja."
            )
            }
    )
    @DELETE
    @Path("{id}")
    public Response odstraniNakupovalniSeznam(@PathParam("id") Integer id){

        //TODO: a je treba pobrisat se artikle

        return Response
                .status(Response.Status.NO_CONTENT)
                .entity(upravljanjeNakupovalnihSeznamovZrno.odstraniSeznam(id))
                .build();

    }

}
