import { Component, OnInit } from '@angular/core';
import {Uporabnik} from './models/uporabnik';
import {UporabnikService} from './services/uporabnik.service';
import {ActivatedRoute, Params, Router} from '@angular/router';
import {Location} from '@angular/common';
import {switchMap} from 'rxjs/operators';

@Component({
  selector: 'app-uporabnik-uredi',
  templateUrl: './uporabnik-uredi.component.html',
  styleUrls: ['./uporabnik-uredi.component.css']
})
export class UporabnikUrediComponent implements OnInit {
  uporabnik: Uporabnik;
  posodobljen: Uporabnik = new Uporabnik();

  constructor(private uporabnikService: UporabnikService,
              private route: ActivatedRoute,
              private router: Router,
              private location: Location) {
  }

  submitForm(): void {
    this.uporabnikService
        .update(this.uporabnik.id, this.posodobljen)
        .subscribe(() => this.router.navigate(['/uporabniki', this.uporabnik.id]));
  }

  nazaj(): void {
    this.location.back();
  }

  ngOnInit(): void {
    this.route.params.pipe(
        switchMap((params: Params) => this.uporabnikService.getUporabnik(+params['id'])))
        .subscribe(uporabnik => this.uporabnik = uporabnik);
  }

}
