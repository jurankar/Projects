import {NakupovalniSeznam} from '../../nakupovalniSeznam/models/nakupovalniSeznam';

export class Uporabnik {
    id: number;
    ime: string;

    // ostali atributi
    priimek: string;
    uporabniskoIme: string;
    email: string;
    nakupovalniSeznami: Array<NakupovalniSeznam>;
}
