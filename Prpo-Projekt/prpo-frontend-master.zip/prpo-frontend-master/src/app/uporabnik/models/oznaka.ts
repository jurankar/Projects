export class Oznaka {
    id: number;
    naslov: string;
    opis: string;
}
