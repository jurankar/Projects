export class Artikel {
    id: number;
    imeArtikla: string;
    cena: number;
    kolicina: number;
}
