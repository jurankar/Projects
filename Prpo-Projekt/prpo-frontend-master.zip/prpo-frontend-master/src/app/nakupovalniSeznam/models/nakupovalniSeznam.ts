import {Uporabnik} from '../../uporabnik/models/uporabnik';
import {Artikel} from '../../uporabnik/models/artikel';
import {Oznaka} from '../../uporabnik/models/oznaka';

export class NakupovalniSeznam {
    id: number;
    naziv: string;
    opis: string;
    uporabnik: Uporabnik;
    seznamArtiklov: Array<Artikel>;
    oznake: Array<Oznaka>;
    imageLink: string;
    ustvarjen: string;
}
