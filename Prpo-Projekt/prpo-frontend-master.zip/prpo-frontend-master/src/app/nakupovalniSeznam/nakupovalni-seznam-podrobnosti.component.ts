import { Component, OnInit } from '@angular/core';
import {NakupovalniSeznam} from './models/nakupovalniSeznam';
import {ActivatedRoute, Params, Router} from '@angular/router';
import {Location} from '@angular/common';
import {switchMap} from 'rxjs/operators';
import {NakupovalniSeznamService} from './services/nakupovalniSeznam.service';

@Component({
  selector: 'app-nakupovalni-seznam-podrobnosti',
  templateUrl: './nakupovalni-seznam-podrobnosti.component.html',
  styleUrls: ['./nakupovalni-seznam-podrobnosti.component.css']
})
export class NakupovalniSeznamPodrobnostiComponent implements OnInit {
  nakupovalniSeznam: NakupovalniSeznam;

  constructor(private nakupovalniSeznamService: NakupovalniSeznamService,
              private route: ActivatedRoute,
              private location: Location,
              private router: Router) {
  }

  ngOnInit(): void {
    this.route.params.pipe(
        switchMap((params: Params) => this.nakupovalniSeznamService.getNakupovalniSeznam(+params['id'])))
        .subscribe(nakupovalniSeznam => this.nakupovalniSeznam = nakupovalniSeznam);
  }

  nazaj(): void {
    this.location.back();
  }

  /*urediUporabnika(id: number) {
    this.router.navigate(['/urediuporabnika', id]);
  }*/

}
