import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';

import {AppRoutingModule} from './app-routing.module';

import {AppComponent} from './app.component';
import {UporabnikiComponent} from './uporabnik/uporabniki.component';
import {UporabnikiDodajComponent} from './uporabnik/uporabniki-dodaj.component';
import {UporabnikPodrobnostiComponent} from './uporabnik/uporabnik-podrobnosti.component';
import {UporabnikService} from './uporabnik/services/uporabnik.service';;
import { UporabnikUrediComponent } from './uporabnik/uporabnik-uredi.component';
import { NakupovalniSeznamPodrobnostiComponent } from './nakupovalniSeznam/nakupovalni-seznam-podrobnosti.component';
import {NakupovalniSeznamService} from './nakupovalniSeznam/services/nakupovalniSeznam.service';


@NgModule({
    imports: [
        BrowserModule,
        HttpClientModule,
        AppRoutingModule,
        FormsModule
    ],
    declarations: [
        AppComponent,
        UporabnikiComponent,
        UporabnikPodrobnostiComponent,
        UporabnikiDodajComponent,
        UporabnikUrediComponent,
        NakupovalniSeznamPodrobnostiComponent,
    ],
    providers: [UporabnikService, NakupovalniSeznamService],
    bootstrap: [AppComponent]
})
export class AppModule {
}

