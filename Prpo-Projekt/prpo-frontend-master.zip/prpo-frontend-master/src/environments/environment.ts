export const environment = {
    production: false,
    apiUrl: 'https://api.prpo.si/v1'
};
