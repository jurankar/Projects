export const environment = {
    production: true,
    apiUrl: 'https://api.prpo.si/v1'
};
