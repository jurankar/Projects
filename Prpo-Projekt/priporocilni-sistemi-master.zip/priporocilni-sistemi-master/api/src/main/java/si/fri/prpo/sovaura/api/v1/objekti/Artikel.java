package si.fri.prpo.sovaura.api.v1.objekti;

public class Artikel {
    private String imeArtikla;
    private  Integer stPojavitev;

    //konstruktorji
    public Artikel (String imeArtikla){
        this.imeArtikla = imeArtikla;
        this.stPojavitev = 1;
    }

    //getterji


    public String getImeArtikla() {
        return imeArtikla;
    }

    public Integer getStPojavitev() {
        return stPojavitev;
    }

    //setterji

    public void setImeArtikla(String imeArtikla) {
        this.imeArtikla = imeArtikla;
    }

    public void setStPojavitev(Integer stPojavitev) {
        this.stPojavitev = stPojavitev;
    }
}
