package si.fri.prpo.sovaura.api.v1.viri;


import si.fri.prpo.sovaura.api.v1.DTO.ArtikelDto;
import si.fri.prpo.sovaura.api.v1.objekti.Artikel;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@ApplicationScoped
@Path("pogosti_artikli")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PogostiArtikli {

    List<Artikel> artikli = new ArrayList<>();

    @GET
    public Response pridobiPogosteArtikle() {   //artikli ki se veckrat kot 2-krat pojavjo v seznamih

        List<Artikel> pogostiArtikli = new ArrayList<Artikel>();

        for(int i = 0; i < artikli.size(); i++){
            Artikel art = artikli.get(i);
            if(art.getStPojavitev() > 2)
                pogostiArtikli.add(art);
        }

        return Response.status(Response.Status.OK).entity(pogostiArtikli).build();
    }

    @POST
    public Response dodajArtikel(ArtikelDto artikelDto) {
        //prvo gre cez vse artikle, ce je ze vstavljen samo doda kolicino,
        //sicer pa doda nov vnos v "artikli"

        String ime = artikelDto.getImeArtikla();
        Artikel art1 = new Artikel(ime);

        boolean vsebuje = false;
        //ce ze vsebuje artikel
        for(int i = 0; i < artikli.size(); i++){
            Artikel art2 = artikli.get(i);
            if(art1.getImeArtikla() .equals(art2.getImeArtikla())){
                vsebuje = true;
                art2.setStPojavitev(art2.getStPojavitev() + 1);
            }
        }
        //ce je nov artikel
        if(!vsebuje){
            artikli.add(art1);
        }

        // uredi artikle po pojavitvah padajoce, preden vrnes
        Collections.sort(artikli, new Comparator<Artikel>() {
            @Override
            public int compare(Artikel o1, Artikel o2) {
                return Integer.valueOf(o2.getStPojavitev()).compareTo(o1.getStPojavitev());
            }
        });

        // vrni prve 3 najpogostejse artikle
        ArrayList<Artikel> najpogostejsiArtikli = new ArrayList<>(3);
        int trenutniIndex = 0;
        for (Artikel trenutni: artikli) {
            if(trenutniIndex < 3){
                najpogostejsiArtikli.add(trenutni);
                trenutniIndex++;
            }
            else break;
        }
        return Response.ok(najpogostejsiArtikli).build();
    }
}