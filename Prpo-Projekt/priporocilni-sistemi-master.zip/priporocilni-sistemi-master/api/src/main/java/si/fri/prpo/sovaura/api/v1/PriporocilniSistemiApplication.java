package si.fri.prpo.sovaura.api.v1;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("v1")
public class PriporocilniSistemiApplication extends Application {

}
