package si.fri.prpo.sovaura.api.v1.DTO;

import si.fri.prpo.sovaura.api.v1.objekti.Artikel;

import java.io.Serializable;
import java.util.List;

public class ArtikelDto implements Serializable {

    private String imeArtikla;
    //private int pojavitve;


    //getter setter

    public String getImeArtikla() {
        return imeArtikla;
    }

    public void setImeArtikla(String imeArtikla) {
        this.imeArtikla = imeArtikla;
    }
}
