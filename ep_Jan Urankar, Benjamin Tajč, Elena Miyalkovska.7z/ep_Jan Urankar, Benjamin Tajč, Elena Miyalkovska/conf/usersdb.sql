-- noinspection SqlDialectInspectionForFile

-- to import use: mysql -u root -p < NetBeansProjects/Gaming_Shop/sql/usersdb.sql

-- shema usersdb
DROP DATABASE IF EXISTS usersdb;
CREATE DATABASE usersdb;
USE usersdb;

-- tabela USER
DROP TABLE IF EXISTS `user`;
CREATE TABLE `usersdb`.`user` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ime` VARCHAR(45) NOT NULL,
  `priimek` VARCHAR(45) NOT NULL,
  `naslov` VARCHAR(45) NULL,
  `email` VARCHAR(45) NOT NULL,
  `geslo` VARCHAR(200) NOT NULL,
  `cert_name` VARCHAR(200) NOT NULL DEFAULT 'undefined',
  `user_type` VARCHAR(200) NOT NULL,    --  prodajalec, stranka, (admininstrator --> TODO ne smemo ga kreirati z registracijo)
   `is_verified` TINYINT DEFAULT 0,     -- ko potrdi mail damo ta variabla na 1
   `verif_key` VARCHAR(200) NOT NULL DEFAULT -1,
   constraint email
        unique (email), # --email index povzroča težave, se v nedeljo zmenimo kako je s tem:: zaenkrat sem ga pobrisal
  PRIMARY KEY (`id`)) ;

ALTER TABLE `usersdb`.`user`
ADD COLUMN `isActive` TINYINT NOT NULL DEFAULT 1 AFTER `user_type`;


-- tabela ARTIKLI
CREATE TABLE `usersdb`.`artikli` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ime` VARCHAR(45) NOT NULL,
  `opis` VARCHAR(420) NOT NULL,
  `cena` FLOAT,
  `isActive` TINYINT NOT NULL DEFAULT 1,
  `creatorId` INT REFERENCES user(`id`),
  `img_name` VARCHAR(420) NOT NULL DEFAULT 'no_pic',
  PRIMARY KEY (`id`));
  
  
  -- tabela ORDERS
CREATE TABLE `usersdb`.`orders` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `status` varchar(45) NOT NULL DEFAULT 'unprocessed',
  `customerId` INT REFERENCES user(`id`),
   OrderDate DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`));
  
  -- tabela order-product junction
  CREATE TABLE `usersdb`.`OPjunction` ( 
  `productId` INT REFERENCES artikli(`id`),
  `orderId` INT REFERENCES orders(`id`),
  `num_of_items` INT NOT NULL DEFAULT -1,        -- če je vrednost -1 pol mamo error
  PRIMARY KEY (`productId`,`orderId`));


CREATE TABLE rating
(
    uid                  int not null,
    pid                  int not null,
    rating                int not null,
    primary key (uid, pid)
);

alter table artikli
    add avg_rating int default 0 null;

-- $2y$10$HsZzHVUbmRPTheyx5l8sC.39OKQx2Bt68Lvv7sKeyUY45MF4UBmnC  ==> geslo123
INSERT INTO `user` (ime, priimek, naslov, email, geslo, user_type, isActive, is_verified) values ('stranka', 'stranka', 'stranka', 'stranka@gmail.com', '$2y$10$HsZzHVUbmRPTheyx5l8sC.39OKQx2Bt68Lvv7sKeyUY45MF4UBmnC', 'Stranka', 1, 1);
INSERT INTO `user` (ime, priimek, naslov, email, geslo, user_type, isActive, is_verified) values ('prodajalec', 'prodajalec', 'prodajalec', 'prodajalec@gmail.com', '$2y$10$HsZzHVUbmRPTheyx5l8sC.39OKQx2Bt68Lvv7sKeyUY45MF4UBmnC', 'Prodajalec', 1, 1);
INSERT INTO `user` (ime, priimek, naslov, email, geslo, user_type, isActive, is_verified) values ('admin', 'admin', 'admin', 'admin@gmail.com', '$2y$10$HsZzHVUbmRPTheyx5l8sC.39OKQx2Bt68Lvv7sKeyUY45MF4UBmnC', 'Administrator', 1, 1);


INSERT INTO `user` (ime, priimek, naslov, email, geslo, user_type, isActive, is_verified) values ('test', 'test', 'test', 'test3@test.test', '$2y$10$HsZzHVUbmRPTheyx5l8sC.39OKQx2Bt68Lvv7sKeyUY45MF4UBmnC', 'Prodajalec', 1, 1);
INSERT INTO `user` (ime, priimek, naslov, email, geslo, user_type, isActive, is_verified) values ('test', 'test', 'test', 'test4@test.test', '$2y$10$HsZzHVUbmRPTheyx5l8sC.39OKQx2Bt68Lvv7sKeyUY45MF4UBmnC', 'Stranka', 1, 1);
INSERT INTO `artikli` (ime, opis, cena, isActive, creatorID, img_name) VALUES ('Call of Duty: Modern Warfare 2', 'The most-anticipated game of the year and the sequel to the best-selling first-person action game of all time, Modern Warfare 2 continues the gripping and heart-racing action as players face off against a new threat dedicated to bringing the world to the brink of collapse.', 27.98, 1, 1, 'cod.jpeg');
INSERT INTO `artikli` (ime, opis, cena, isActive, creatorID, img_name) VALUES ('League of Legends', 'League of Legends (abbreviated LoL or League) is a 2009 multiplayer online battle arena video game developed and published by Riot Games for Microsoft Windows and macOS. Originally inspired by Defense of the Ancients, the game has followed a freemium model since its release on October 27, 2009. ', 9.99, 1, 1, 'lol.jpeg');
INSERT INTO `artikli` (ime, opis, cena, isActive, creatorID, img_name) VALUES ('World of Warcraft', 'World of Warcraft (WoW) is a massively multiplayer online role-playing game (MMORPG) released in 2004 by Blizzard Entertainment. It is the fourth released game set in the Warcraft fantasy universe.[3] World of Warcraft takes place within the Warcraft world of Azeroth, approximately four years after the events at the conclusion of Blizzard''s previous Warcraft release.', 49.99, 1, 1, 'wow.jpeg');
INSERT INTO `orders` (customerId) VALUES (2);
INSERT INTO `OPjunction` (productId, orderId, num_of_items) VALUES (1, 1, 2);
