gesla za certifikate: ep ali eo

stranka:
	e-naslov: stranka@gmail.com
	geslo: geslo123
prodajalec:
	e-naslov: prodajalec@gmail.com
	geslo: geslo123
administrator:
	e-naslov: admin@gmail.com
	geslo: geslo123


dodatna navodila v certs/info.txt